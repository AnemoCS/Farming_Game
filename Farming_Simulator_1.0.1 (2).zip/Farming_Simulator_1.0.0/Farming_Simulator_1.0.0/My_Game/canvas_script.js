function draw() {
    // 1. Get the canvas element
    const canvas = document.getElementById("myCanvas");

    // 2. Get the 2D rendering context
    const ctx = canvas.getContext("2d");

    // 3. Draw on the canvas (e.g., a red rectangle)
    ctx.fillStyle = "red"; // Set the fill color
    ctx.fillRect(0, 0, 150, 75); // Draw a filled rectangle
}

function drawWheat() {
  const canvas = document.getElementById("wheatIcon");
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = "red";
  ctx.fillRect(0, 0, 150, 75);
  ctx.background = 0,0,0;
 
}



// Call the draw function when the window loads
window.onload = draw;
window.onload = drawWheat;

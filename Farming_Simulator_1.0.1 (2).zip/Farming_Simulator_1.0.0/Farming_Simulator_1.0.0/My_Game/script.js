"use strict"; //Strict mode
const upgradeButton = document.getElementById("upgradeButton"); 
const wheatMultiplier = 1.2;
let seconds = 0;
let wheatCost = 10;
let wheatPrice = 0;
let wheatCounter = 0;
 
upgradeButton.textContent = "Cost: Free";

function changeUpgradeButton() {
 wheatCounter++;
 if (wheatCounter == 1) {
  wheatPrice = 1;
   upgradeButton.textContent = "Upgrade Cost: " + cost;
 } else {
   let cost = Math.round(wheatCost * wheatMultiplier);
   wheatCost = cost;
   wheatPrice += 1;
    upgradeButton.textContent = "Upgrade Cost: " + cost;
 }
 
}

function updateCoins() {
 seconds++;
 //TODO: CHANGE TO COINS LABEL

}